import os
import tempfile
from flask import Flask, request, render_template, send_from_directory,send_file
from PIL import Image
import fitz
import cv2
import pytesseract
import base64
from io import BytesIO
from collections import defaultdict
import io

import json
import numpy as np



import xml.etree.ElementTree as ET

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['OUTPUT_FOLDER'] = 'output'
app.config['IMAGE_FOLDER']  = 'image'
 

def extract_coordinates_from_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()

    coordinates = []

    for element in root.iter('object'):
        coordinate_elem = element.find('bndbox')
        if coordinate_elem is not None:
            name_elem = element.find('name')
            if name_elem is not None:
                name = name_elem.text
                x_min = float(coordinate_elem.find('xmin').text)
                y_min = float(coordinate_elem.find('ymin').text)
                x_max = float(coordinate_elem.find('xmax').text)
                y_max = float(coordinate_elem.find('ymax').text)
                width = x_max - x_min
                height = y_max - y_min
                coordinates.append((name, x_min, y_min, width, height))

    return coordinates


def extract_coordinates_from_directory(directory_path):
    xml_files = sorted([file for file in os.listdir(directory_path) if file.endswith('.xml')])

    all_coordinates = []
    page_coordinates = []
    page_number = 1

    for xml_file in xml_files:
        xml_path = os.path.join(directory_path, xml_file)
        extracted_coordinates = extract_coordinates_from_xml(xml_path)

        # Append coordinates separately for each page
        page_coordinates.append(extracted_coordinates)
        all_coordinates.extend([(coord + (page_number,)) for coord in extracted_coordinates])

        page_number += 1

    return page_coordinates

def extract_text_from_image(image_path, coordinates):
    # Load the image using OpenCV
    image = cv2.imread(image_path)

    # Extract text from each defined coordinate
    extracted_text = []
    for (object_name, x, y, width, height) in coordinates:
        # Convert coordinates to integers
        x, y, width, height = int(x), int(y), int(width), int(height)

        # Extract the region of interest from the image
        roi = image[y:y+height, x:x+width]

        # Convert the region of interest to grayscale
        gray_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        # Apply thresholding to enhance text
        _, thresholded_roi = cv2.threshold(gray_roi, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

        # Use Tesseract OCR to extract text from the thresholded region of interest
        text = pytesseract.image_to_string(thresholded_roi)

        # Append the object name and extracted text to the result list
        extracted_text.append((object_name, text))

    return extracted_text

import xml.etree.ElementTree as ET
from PIL import Image
import io
import base64
from PIL import Image
import io
import base64

from PIL import Image
import io
import base64

from PIL import Image
import io
import base64




def extract_coordinates_from_xml_template(xml_paths):
    all_coordinates = []
 
    all_image_coordinates=[]
    for xml_path in xml_paths:
    #     print(xml_path)
        coordinates = []
        image_coordinates = []
        tree = ET.parse(xml_path)
        root = tree.getroot()
    #     print(tree)
        for element in root.iter('object'):
            coordinate_elem = element.find('bndbox')
    #         print(coordinate_elem)
            if coordinate_elem is not None:
                name_elem = element.find('name')
    #             print(name_elem)
                if name_elem is not None:
                    name = name_elem.text
                    x_min = float(coordinate_elem.find('xmin').text)
                    y_min = float(coordinate_elem.find('ymin').text)
                    x_max = float(coordinate_elem.find('xmax').text)
                    y_max = float(coordinate_elem.find('ymax').text)
                    width = x_max - x_min
                    height = y_max - y_min
                    coordinates.append((name, x_min, y_min, width, height))
                if name_elem is not None and name_elem.text == 'image':
                    if coordinate_elem is not None:
                        x_min = int(float(coordinate_elem.find('xmin').text))
                        y_min = int(float(coordinate_elem.find('ymin').text))
                        x_max = int(float(coordinate_elem.find('xmax').text))
                        y_max = int(float(coordinate_elem.find('ymax').text))
                        width = x_max - x_min
                        height = y_max - y_min
                        image_coordinates.append((x_min, y_min, width, height))
                    
        all_coordinates.append(coordinates)
        all_image_coordinates.append(image_coordinates)

    return all_coordinates, all_image_coordinates





# Now 'all_coordinates' contains the extracted coordinates, and 'base64_strings' contains the Base64 strings for each XML file.


# def extract_coordinates_from_xml_template(xml_paths):
#     global image_coordinates
#     all_coordinates = []

#     for xml_path in xml_paths:
#         coordinates = []
#         tree = ET.parse(xml_path)
#         root = tree.getroot()

       


#         for element in root.iter('object'):
#             coordinate_elem = element.find('bndbox')
#             if coordinate_elem is not None:
#                 name_elem = element.find('name')
#                 if name_elem is not None:
#                     name = name_elem.text
#                     x_min = float(coordinate_elem.find('xmin').text)
#                     y_min = float(coordinate_elem.find('ymin').text)
#                     x_max = float(coordinate_elem.find('xmax').text)
#                     y_max = float(coordinate_elem.find('ymax').text)
#                     width = x_max - x_min
#                     height = y_max - y_min
#                     coordinates.append((name, x_min, y_min, width, height))
        
#         all_coordinates.append(coordinates)

#     return all_coordinates

def extract_images_from_pdf(pdf_path):
    images = []
    doc = fitz.open(pdf_path)
    for i in range(len(doc)):
        for img in doc.get_page_images(i):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_data = base_image["image"]
            images.append(image_data)
    
    return images


def extract_text_from_images_in_directory(directory_path):
    xml_files = sorted([file for file in os.listdir(directory_path) if file.endswith('.xml')])
    image_files = sorted([file for file in os.listdir(directory_path) if file.endswith('.jpg') or file.endswith('.png')])

    extracted_texts = []

    for xml_file in xml_files:
        xml_path = os.path.join(directory_path, xml_file)
        coordinates = extract_coordinates_from_xml(xml_path)

        if len(image_files) > 0:
            image_file = image_files.pop(0)
            image_path = os.path.join(directory_path, image_file)
            extracted_text = extract_text_from_image(image_path, coordinates)
            extracted_texts.append((image_file, extracted_text))

    return extracted_texts
import cv2
import os
import numpy as np

def search_image_template(template_paths, search_folders):
    found_files = []

    for root, dirs, files in os.walk(search_folders):
        for file in files:
            file_path = os.path.join(root, file)

            # Load the search image with error handling
            search_image = cv2.imread(file_path, cv2.IMREAD_COLOR)
            if search_image is None:
                print(f"Error loading image: {file_path}")
                continue

            # Iterate over each template image
            for template_path in template_paths:
                template = cv2.imread(template_path, cv2.IMREAD_COLOR)
                if template is None:
                    print(f"Error loading template: {template_path}")
                    continue

                template_height, template_width, _ = template.shape
                search_height, search_width, _ = search_image.shape

                # Ensure compatibility of template and search image dimensions
                if search_height < template_height or search_width < template_width:
                    continue

                result = cv2.matchTemplate(search_image, template, cv2.TM_CCOEFF_NORMED)
                threshold = 0.8  # Adjust the threshold as needed

                locations = np.where(result >= threshold)
                if len(locations[0]) > 0:
                    found_files.append(file_path)
                    break  # Move to the next search image

    return found_files


# def is_image_template_present(pdf_folder):
#     return os.path.isdir(pdf_folder) and len(os.listdir(pdf_folder)) > 0
def crop_and_store_base64(image_paths, all_image_coordinates):
    base64_strings = {}

    for i, image_path in enumerate(image_paths):
        coordinates = all_image_coordinates[i]

        image_base64_str_list = []
        for x_min, y_min, width, height in coordinates:
            image = Image.open(image_path)
            cropped_image = image.crop((x_min, y_min, x_min + width, y_min + height))
            buffered = io.BytesIO()
            cropped_image.save(buffered, format="JPEG")  # Change format as needed
            base64_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
            image_base64_str_list.append(base64_str)

        base64_strings[image_path] = image_base64_str_list

    return base64_strings



def convert_pdf_to_images(pdf_path, output_directory, dpi=300):
    global pdf_folder
    # Create output directory if it doesn't exist
    # os.makedirs(output_directory, exist_ok=True)

    # Extract the PDF name without extension
    pdf_name = os.path.splitext(os.path.basename(pdf_path))[0]
    # Create a new folder for the PDF file
    pdf_folder = os.path.join(output_directory, pdf_name)
    os.makedirs(pdf_folder, exist_ok=True)
    

    

    # Check if image template is already present
    # if is_image_template_present(pdf_folder):
    #     return True
    # global template_path
    global appened_image_path
    appened_image_path =[]
    # Open the PDF file using PyMuPDF
    with fitz.open(pdf_path) as doc:
        for i, page in enumerate(doc):
            # Render the page as an image
            pix = page.get_pixmap(matrix=fitz.Matrix(dpi/72, dpi/72))
            image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

            # Save the image with the specified filename
            image_filename = f"{pdf_name}_Page{i+1}.jpg"
        
            image_path = os.path.join(pdf_folder, image_filename)
            
            
            # template_path.append(image_path)
            image.save(image_path, "JPEG")
            appened_image_path.append(image_path)
    print(appened_image_path)
    found_files=search_image_template(appened_image_path,output_directory)
    
    # print(found_files)
    xml_extension = '.xml'
    found_files_with_xml = []

    if not found_files:
        return "Successfully converted PDF to Image!!!"

    for image_file_path in found_files:
        image_folder = os.path.dirname(image_file_path)
        image_file_name = os.path.basename(image_file_path)
        xml_file_path = os.path.join(image_folder, image_file_name.replace('.jpg', xml_extension))

        if os.path.exists(xml_file_path):
            found_files_with_xml.append(xml_file_path)
    # print(found_files_with_xml)

      
    return found_files_with_xml
def replace_base64_strings(text_list, base64_dict):
    new_text_list = []
    for image_file, data in text_list:
        base64_str_list = base64_dict.get(image_file, [])
        num_base64_strings = len(base64_str_list)
        index = 0
        
        new_data = []
        for key, value in data:
            if key == 'image':
                if index < num_base64_strings:
                    new_data.append(('image', base64_str_list[index]))
                    index += 1
            else:
                new_data.append((key, value))
        
        new_text_list.append((image_file, new_data))
    
    return new_text_list

@app.route('/', methods=['GET', 'POST'])
def convert():
    if request.method == 'POST':
        # Check if a PDF file is provided
        if 'pdf' not in request.files:
            return "No PDF file provided."

        pdf_file = request.files['pdf']

        # Check if the file has a valid extension
        if not pdf_file.filename.endswith('.pdf'):
            return "Invalid file format. Please provide a PDF file."

        # Save the PDF file to the upload directory
        upload_dir = app.config['UPLOAD_FOLDER']
        pdf_path = os.path.join(upload_dir, pdf_file.filename)
        pdf_file.save(pdf_path)

        # pdf_dir = os.path.dirname(pdf_path)
        

        # Convert PDF to images
        output_dir = app.config['OUTPUT_FOLDER']
        
        # pdf_folder = os.path.join(output_dir, pdf_name)
        # os.makedirs(pdf_folder, exist_ok=True)
       
        templates_present = convert_pdf_to_images(pdf_path, output_dir)


        # found_files = search_image_template(template_paths, search_folders)
        
        # print(page_coordinates)

        if templates_present:
           
            base64_string_index=0
            coordinates,all_image_coordinates= extract_coordinates_from_xml_template(templates_present)
            base64_strings = crop_and_store_base64(appened_image_path, all_image_coordinates)

            # print(templates_present)
            # print("base64stringstarting",base64_strings)
            # print(len(base64_strings))

        
                

            if len(appened_image_path) > 0:
                extracted_texts = []
                image_to_base64 = {}  # Create a dictionary to store the mapping between image files and base64 strings

                for xml_path, coordinate in zip(templates_present, coordinates):
                    image_file = appened_image_path.pop(0)
                    extracted_text = extract_text_from_image(image_file, coordinate)
                    
                    # # Check if the image_file is already in the dictionary, if not, fetch the base64_str
                    # if image_file not in image_to_base64:
                    #     base64_str = base64_strings.get(xml_path, '')  # Get the base64 string or empty string if key not found
                    #     image_to_base64[image_file] = base64_str

                    # # Iterate through the extracted text and replace 'image' keys with base64 strings
                    # for i, (key, value) in enumerate(extracted_text):
                    #     if key == 'image':
                    #         # Look up the correct base64_str for the current image_file
                    #         base64_str = image_to_base64.get(image_file, '')
                    #         extracted_text[i] = ('image', base64_str)

                    extracted_texts.append((image_file, extracted_text))
                # print(extracted_texts)
                extracted_texts=replace_base64_strings(extracted_texts, base64_strings)
                # replace_base64=replace_base64_strings(extracted_texts, base64_strings)
                # print(replace_base64)
                # print(extracted_texts)


                image_streams = {}

                # for image_file, image_data_list in base64_strings.items():
                #     # Extract the first Base64 encoded image string from the list
                #     image_data = image_data_list[0]

                #         # Convert the Base64 string back to bytes
                #     image_bytes = base64.b64decode(image_data)

                #     # Create an in-memory file-like object from the bytes
                #     image_stream = BytesIO(image_bytes)
                #     image_streams[image_file] = base64.b64encode(image_bytes).decode('utf-8')
                # print(image_streams)
                for image_file, image_data_list in base64_strings.items():
                    image_list = []  # Initialize a list to store multiple images for the same key
                    for image_data in image_data_list:
                        # Convert the Base64 string back to bytes
                        image_bytes = base64.b64decode(image_data)

                        # Create an in-memory file-like object from the bytes
                        image_stream = BytesIO(image_bytes)

                        # Append the Base64-encoded image to the list
                        image_list.append(base64.b64encode(image_bytes).decode('utf-8'))

                    # Store the list of Base64-encoded images in the image_streams dictionary
                    image_streams[image_file] = image_list

        
               

                json_data = json.dumps(extracted_texts, indent=4)
                return render_template('index.html',extracted_texts=extracted_texts,json_data=json_data,image_streams=image_streams)

  
        else:

            page_coordinates = extract_coordinates_from_directory(pdf_folder)

            extracted_texts = extract_text_from_images_in_directory(pdf_folder)


            extracted_data = []
            for image_file, extracted_text in extracted_texts:
                data = {'Image File': image_file}
                for key, value in extracted_text:
                    data[key] = value.strip()
                extracted_data.append(data)

            json_data = json.dumps(extracted_data, indent=4)
            return render_template('index.html',extracted_texts=extracted_texts,json_data=json_data)


        # return render_template('index.html',page_coordinates=page_coordinates,json_data=json_data)

    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download():
    json_data = request.form.get('json_data')

    if json_data:
        # Create a temporary file path
        temp_dir = tempfile.gettempdir()
        json_path = os.path.join(temp_dir, 'extracted_texts.json')

        # Write JSON data to the temporary file
        with open(json_path, 'w') as json_file:
            json_file.write(json_data)

        # Return the temporary file as a downloadable attachment
        return send_from_directory(temp_dir, 'extracted_texts.json', as_attachment=True)

    return "Invalid JSON data."


@app.route('/output/<path:filename>')
def download_output(filename):
    return send_from_directory(app.config['OUTPUT_FOLDER'], filename)

if __name__ == '__main__':
    app.run()
